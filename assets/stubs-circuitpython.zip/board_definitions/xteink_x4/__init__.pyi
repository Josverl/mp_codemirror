# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for Xteink X4
 - port: espressif
 - board_id: xteink_x4
 - NVM size: 8192
 - Included modules: _asyncio, _bleio, _bleio (native), _eve, _pixelmap, adafruit_bus_device, adafruit_pixelbuf, aesio, alarm, analogbufio, analogio, array, atexit, binascii, bitbangio, bitmapfilter, bitmaptools, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, codeop, collections, digitalio, displayio, epaperdisplay, errno, espidf, espnow, fontio, fourwire, framebufferio, getpass, gifio, hashlib, i2cdisplaybus, io, ipaddress, jpegio, json, locale, lvfontio, math, max3421e, mdns, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, ps2io, random, re, rtc, sdcardio, select, sharpdisplay, socketpool, socketpool.socketpool.AF_INET6, ssl, storage, struct, supervisor, supervisor.get_setting, sys, terminalio, tilepalettemapper, time, touchio, traceback, usb, vectorio, warnings, watchdog, wifi, zlib
 - Frozen libraries: 
"""

# Imports
import busio
import displayio
import microcontroller


# Board Info:
board_id: str


# Pins:
BUTTON: microcontroller.Pin  # GPIO3
BOOT0: microcontroller.Pin  # GPIO3
A0: microcontroller.Pin  # GPIO0
A1: microcontroller.Pin  # GPIO1
BUTTON_ADC_1: microcontroller.Pin  # GPIO1
A2: microcontroller.Pin  # GPIO2
BUTTON_ADC_2: microcontroller.Pin  # GPIO2
RX: microcontroller.Pin  # GPIO20
D20: microcontroller.Pin  # GPIO20
MOSI: microcontroller.Pin  # GPIO10
EPD_MOSI: microcontroller.Pin  # GPIO10
D10: microcontroller.Pin  # GPIO10
SCK: microcontroller.Pin  # GPIO8
EPD_SCK: microcontroller.Pin  # GPIO8
D8: microcontroller.Pin  # GPIO8
MISO: microcontroller.Pin  # GPIO7
SD_MISO: microcontroller.Pin  # GPIO7
SD_CS: microcontroller.Pin  # GPIO12
EPD_BUSY: microcontroller.Pin  # GPIO6
EPD_RESET: microcontroller.Pin  # GPIO5
EPD_DC: microcontroller.Pin  # GPIO4
EPD_CS: microcontroller.Pin  # GPIO21


# Members:
def SPI() -> busio.SPI:
    """Returns the `busio.SPI` object for the board's designated SPI bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.SPI`.
    """

"""Returns the `displayio.EPaperDisplay` object for the board's built in display.
The object created is a singleton, and uses the default parameter values for `displayio.EPaperDisplay`.
"""
DISPLAY: displayio.EPaperDisplay


# Unmapped:
#   none
