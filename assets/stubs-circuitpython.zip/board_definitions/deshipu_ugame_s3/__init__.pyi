# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for uGame S3
 - port: espressif
 - board_id: deshipu_ugame_s3
 - NVM size: 8192
 - Included modules: _asyncio, _bleio, _bleio (native), _eve, _pixelmap, _stage, adafruit_bus_device, adafruit_pixelbuf, aesio, alarm, analogbufio, analogio, array, atexit, audiobusio, audiocore, audiomixer, audiomp3, binascii, bitbangio, bitmapfilter, bitmaptools, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, codeop, collections, countio, digitalio, displayio, epaperdisplay, errno, espidf, espnow, espulp, fontio, fourwire, frequencyio, getpass, gifio, hashlib, i2cdisplaybus, io, ipaddress, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, max3421e, mdns, memorymap, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, ps2io, pulseio, pwmio, rainbowio, random, re, rtc, sdcardio, sdioio, select, socketpool, socketpool.socketpool.AF_INET6, ssl, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, touchio, traceback, ulab, usb, usb_cdc, usb_hid, usb_midi, vectorio, warnings, watchdog, wifi, zlib
 - Frozen libraries: pew, stage, ugame
"""

# Imports
import displayio
import microcontroller


# Board Info:
board_id: str


# Pins:
P1: microcontroller.Pin  # GPIO43
P2: microcontroller.Pin  # GPIO44
P3: microcontroller.Pin  # GPIO3
P4: microcontroller.Pin  # GPIO4
P5: microcontroller.Pin  # GPIO5
P6: microcontroller.Pin  # GPIO6
P7: microcontroller.Pin  # GPIO7
BUTTON_LEFT: microcontroller.Pin  # GPIO1
BUTTON_UP: microcontroller.Pin  # GPIO2
BUTTON_RIGHT: microcontroller.Pin  # GPIO42
BUTTON_DOWN: microcontroller.Pin  # GPIO41
BUTTON_X: microcontroller.Pin  # GPIO0
BUTTON_O: microcontroller.Pin  # GPIO48
BUTTON_Z: microcontroller.Pin  # GPIO47
LIGHT: microcontroller.Pin  # GPIO14
BATTERY: microcontroller.Pin  # GPIO8
AUDIO_BCLK: microcontroller.Pin  # GPIO15
AUDIO_LRCLK: microcontroller.Pin  # GPIO16
AUDIO_DATA: microcontroller.Pin  # GPIO17
AUDIO_GAIN: microcontroller.Pin  # GPIO18
TFT_RESET: microcontroller.Pin  # GPIO13
TFT_CS: microcontroller.Pin  # GPIO10
TFT_DC: microcontroller.Pin  # GPIO9
TFT_BACKLIGHT: microcontroller.Pin  # GPIO21
TFT_SCK: microcontroller.Pin  # GPIO12
TFT_MOSI: microcontroller.Pin  # GPIO11


# Members:
"""Returns the `displayio.Display` object for the board's built in display.
The object created is a singleton, and uses the default parameter values for `displayio.Display`.
"""
DISPLAY: displayio.Display


# Unmapped:
#   none
