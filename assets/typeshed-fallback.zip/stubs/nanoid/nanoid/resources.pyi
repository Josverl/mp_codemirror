alphabet: str
size: int
